﻿# -*- coding: utf-8 -*-

import nltk
from nltk.corpus import stopwords
from nltk.cluster.util import cosine_distance
import numpy as np
import networkx as nx
import re
import kss
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('--filename', type = str, default = './data/lecture_note4.txt',
                    help = 'File name to summarize.')
parser.add_argument('--stopword_file', type = str, default = './data/korean_stopwords_list.txt',
                    help = 'Stopwords filename that includes some words must be removed.')
parser.add_argument('--top_n', type = int, default = 5,
                    help = 'Num of sentences that summarized text.')
args = parser.parse_args()

def read_txt(file_name):
    f = open(file_name, mode = 'r', encoding = 'utf-8')
    
    sentences = []
    
    for s in f:
        if s == '\n':
            continue
        for sentence in kss.split_sentences(s):
            hangul = re.compile('[^ \u3131-\u3163\uac00-\ud7a3]+')
            sentences.append(hangul.sub('', sentence).split(" "))

    f.close

    return sentences

def read_stopwords(stopword_file):
    with open(stopword_file, 'r', encoding = 'utf-8') as f:
        data = [line for line in f.read().splitlines()]
        return data

def sentence_similarity(sent1, sent2, stopwords=None):
    if stopwords is None:
        stopwords = []
 
    sent1 = [w.lower() for w in sent1]
    sent2 = [w.lower() for w in sent2]
 
    all_words = list(set(sent1 + sent2))
 
    vector1 = [0] * len(all_words)
    vector2 = [0] * len(all_words)
 
    # build the vector for the first sentence
    for w in sent1:
        if w in stopwords:
            continue
        vector1[all_words.index(w)] += 1
 
    # build the vector for the second sentence
    for w in sent2:
        if w in stopwords:
            continue
        vector2[all_words.index(w)] += 1
 
    return 1 - cosine_distance(vector1, vector2)
 
def build_similarity_matrix(sentences, stop_words):
    # Create an empty similarity matrix
    similarity_matrix = np.zeros((len(sentences), len(sentences)))
 
    for idx1 in range(len(sentences)):
        for idx2 in range(len(sentences)):
            if idx1 == idx2: #ignore if both are same sentences
                continue 
            similarity_matrix[idx1][idx2] = sentence_similarity(sentences[idx1], sentences[idx2], stop_words)

    return similarity_matrix


def generate_summary(file_name, stopword_file, top_n=5):
    stop_words = read_stopwords(stopword_file)
    # print(stop_words)

    summarize_text = []

    # Step 1 - Read text anc split it
    sentences =  read_txt(file_name)
    # print(sentences)
#     sentences = p.main(file_name)

    # Step 2 - Generate Similary Martix across sentences
    sentence_similarity_martix = build_similarity_matrix(sentences, stop_words)

    # Step 3 - Rank sentences in similarity martix
    sentence_similarity_graph = nx.from_numpy_array(sentence_similarity_martix)
    scores = nx.pagerank(sentence_similarity_graph)
    
    # Step 4 - Sort the rank and pick top sentences
    ranked_sentence = sorted(((scores[i],s) for i,s in enumerate(sentences)), reverse=True)    
    # print("\nIndexes of top ranked_sentence order are \n", ranked_sentence)    

    for i in range(top_n):
        summarize_text.append(" ".join(ranked_sentence[i][1]))

    # Step 5 - Offcourse, output the summarize texr
    # print("\nSummarize Text: \n", ". ".join(summarize_text))

    return summarize_text

if __name__ == '__main__':
    summarized_text = generate_summary(args.filename, args.stopword_file, args.top_n)
    print(summarized_text)